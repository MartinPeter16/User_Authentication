from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from UserApp.serializers import UserSerializer
from UserApp.models import User
from rest_framework.exceptions import AuthenticationFailed

class RegisterView(APIView):
    def post(self,request):
        obj = UserSerializer(data=request.data)
        obj.is_valid(raise_exception=True)
        obj.save()
        return Response(obj.data)

class LoginView(APIView):
    def post(self,request):
        email = request.data['email']
        password = request.data['password']

        x = User.objects.filter(email=email).first()
        if x is None:
            raise AuthenticationFailed("User not found..")

        if not x.check_password(password):
            raise AuthenticationFailed("Incorrect Password..")

        return Response({
            'message':'Success'
        })

